<?php

    include("db_conn.php"); 

    if(isset($_GET['id'])){

        $id = $_GET['id'];

        $query = "SELECT * FROM prospectos WHERE id='$id'"; //setencia SQL
        $respuesta = mysqli_query($conn, $query); //se realiza la peticion

        if(mysqli_num_rows($respuesta) > 0){

            foreach($respuesta as $fila){
                $observacion = $fila['observaciones'];
?>
                <div class="container cont-form">
                <form action="" method="get" id="formulario">
                
                    <div class="form-row">
                        <div class="form-group col-12">
                            
                            <label for="nombre">Nombre:</label>
                            <input type="text" class="form-control" aria-label="nombre" aria-describedby="button-addon2" name="nombre" value="<?=$fila['nombre']?>" id="nombre" required>
                        </div>
                        <div class="form-group col-12">
                            <label for="apellido_p">Apellido paterno:</label>
                            <input type="text" class="form-control" aria-label="apellido_p" name="apellido_p" value="<?=$fila['apellido_p']?>" id="apellido_p" aria-describedby="button-addon2" required>
                        </div>
                        <div class="form-group col-12">
                            <label for="apellido_m">Apellido materno:</label>
                            <input type="text" class="form-control" aria-label="apellido_m" name="apellido_m" value="<?=$fila['apellido_m']?>" id="apellido_m" aria-describedby="button-addon2">
                        </div>
                    </div> 
        
                    <div class="form-row">
                        <div class="form-group col-8">
                            <label for="calle">Calle:</label> 
                            <input type="text" class="form-control" name="calle" value="<?=$fila['calle']?>" id="calle" required>                
                        </div>
                        <div class="form-group col-4">
                            <label for="numero">Número:</label> 
                            <input type="text" class="form-control" name="numero" value="<?=$fila['numero']?>" id="numero" required>                
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-8">
                            <label for="colonia">Colonia:</label> 
                            <input type="text" class="form-control" name="colonia" value="<?=$fila['colonia']?>" id="colonia" required>                
                        </div>
                        <div class="form-group col-4">
                            <label for="codigoP">Código postal:</label> 
                            <input type="text" class="form-control" name="codigoP" value="<?=$fila['codigo_p']?>" id="codigoP" required>                
                        </div>
                    </div>
                    
                    <div class="form-row ">
                        <div class="form-group col-6">
                            <label for="telefono">Teléfono:</label>
                            <input type="text" class="form-control" name="telefono" value="<?=$fila['telefono']?>" id="telefono" required>
                        </div>
                        <?php 
                            if($fila['estatus'] == 3){

                                echo("<div class='form-group col-6'>
                                    <label for='observaciones'>Observaciones de rechazo:</label>
                                    <input type='text' class='form-control' value='".$fila['observaciones']."' name='observaciones' id='observaciones'>
                                    <button type='button' class='btn btn-success' id='btnActualizar".$fila['id']."' >Actualizar</button>
                                </div>");

                            }
                        ?>
                    </div>
        
                    <div class="form-row">
                        <div class="form-group col-6">
                            <label for="rfc">RFC:</label>
                            <input type="text" class="form-control" name="rfc" value="<?=$fila['rfc']?>" id="rfc" required>
                        </div>
                    </div>
        
                    <div class="form-row new-file">
                        <div class="form-group">
                            <label for="files">Documentos:</label>
                            <input type="text" class="form-control-file" value="<?=$fila['documentos']?>" name="file" id="file">
                        </div>
                    </div>
        
                    <div class="btn-group" role="group">
                       
                        <button type="button" class="btn btn-success" id="btnAutorizar<?=$fila['id']?>" onClick="autorizar();">Autorizar</button>
                        <button type="button" class="btn btn-danger" id="btnRechazar<?=$fila['id']?>" onClick="rechazar();">Rechazar</button>

                    </div>
                
                </form>  
            </div>
<?php
    }
        }else{
            echo "No se encuentra el registro";
        }

    }
    


?>

 
<script type="text/javascript"> //js para cambiar a autorizado

    function autorizar(){
        <?php 
        if($fila['estatus']!= 2){
            $autorizar = "UPDATE prospectos SET estatus=2 WHERE id='$id'";
            $respuesta = mysqli_query($conn, $autorizar); //se realiza la peticion
        }

        ?>

        console.log("Autorizaste al prospecto ");
    }

</script>

<script type="text/javascript"> //js para cambiar a rechazado

    function rechazar(){
        <?php 
            if($fila['estatus']!= 3){
                $rechazar = "UPDATE prospectos SET estatus=3 WHERE id='$id'";
                $respuesta = mysqli_query($conn, $rechazar); //se realiza la peticion
            }
        ?>

        console.log("Rechazaste al prospecto ");
    }

</script>

<script type="text/javascript">
    
    function añadirObservacion(){
        <?php
            $añadir = "UPDATE prospectos SET observaciones = 'Respuesta' WHERE id='$id'"; //ingresar una observacion fija
            $respuesta = mysqli_query($conn, $añadir); //se realiza la peticion
        ?>

        console.log("Observacion");

    }
</script>
