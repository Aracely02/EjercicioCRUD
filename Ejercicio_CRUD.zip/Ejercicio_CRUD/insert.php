<?php

    if(isset($_POST['nombre']) && isset($_POST['apellido_p']) && isset($_POST['apellido_m']) //si mis input tienen datos
        && isset($_POST['calle']) && isset($_POST['numero']) && isset($_POST['colonia'])
        && isset($_POST['codigoP']) && isset($_POST['telefono']) && isset($_POST['rfc']) && isset($_POST['file'])){
        
        include 'db_conn.php'; // conexion a db

        //cacheo de datos
        $nombre = $_POST['nombre'];
        $apellido_p = $_POST['apellido_p'];
        $apellido_m = $_POST['apellido_m'];

        $calle = $_POST['calle'];
        $numero = $_POST['numero'];
        $colonia = $_POST['colonia'];
        $codigoP = $_POST['codigoP'];
        $telefono = $_POST['telefono'];
        $rfc = $_POST['rfc'];

        $file = $_POST['file'];
        
        // si una variable está vacia 
        if  (empty($nombre) || empty($apellido_p) || empty($apellido_m) || empty($calle) || empty($numero) || empty($colonia) 
                || empty($codigoP) || empty($telefono) || empty($rfc) || empty($file)){

            header("Location: pantalla_captura.html"); //quedarme en pantalla de captura
            
        } else{

            $query = "INSERT INTO prospectos(nombre, apellido_p,apellido_m,calle,numero,colonia,codigo_p,telefono,rfc, documentos, estatus) 
                        VALUES ('$nombre', '$apellido_p', '$apellido_m', '$calle', '$numero', '$colonia', '$codigoP',
                            '$telefono', '$rfc', '$file', '1')";  //registro de datos a bd

            $respuesta = mysqli_query($conn, $query); //envío del registro

            if($respuesta){ 
                echo "Envio exitoso"; //si se envio correctamente imprimir

            }else{
                echo "No se pudo realizar el envio"; //si no se pude enviar imprimir
            }

        }

    }


?>