<?php

    $server = "localhost";
    $username= "root";
    $password = "";
    $dbname = "prospectos";

    $conn = mysqli_connect($server, $username, $password, $dbname);

    if(!$conn){
        echo "Conexión fallida";
        exit();
    }


