-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 30-11-2021 a las 20:08:33
-- Versión del servidor: 10.4.20-MariaDB
-- Versión de PHP: 7.3.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `prospectos`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estatus`
--

CREATE TABLE `estatus` (
  `id` int(11) NOT NULL,
  `estatus` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `estatus`
--

INSERT INTO `estatus` (`id`, `estatus`) VALUES
(1, 'Enviado'),
(2, 'Autorizado'),
(3, 'Rechazado');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `prospectos`
--

CREATE TABLE `prospectos` (
  `id` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `apellido_p` varchar(50) NOT NULL,
  `apellido_m` varchar(50) NOT NULL,
  `calle` varchar(50) NOT NULL,
  `numero` varchar(10) NOT NULL,
  `colonia` varchar(50) NOT NULL,
  `codigo_p` varchar(10) NOT NULL,
  `telefono` varchar(10) NOT NULL,
  `rfc` varchar(20) NOT NULL,
  `documentos` varbinary(150) NOT NULL,
  `estatus` int(5) NOT NULL,
  `observaciones` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `prospectos`
--

INSERT INTO `prospectos` (`id`, `nombre`, `apellido_p`, `apellido_m`, `calle`, `numero`, `colonia`, `codigo_p`, `telefono`, `rfc`, `documentos`, `estatus`, `observaciones`) VALUES
(1, 'Patricia Aracely', 'Hernandez', 'Lopez', 'Flor de Liz', '6452', 'Bugambilias', '80145', '6672509472', 'something', '', 2, 'Respuesta'),
(5, 'Israel', 'Hernandez', 'Perez', 'Flor de Liz', '6452', 'Bugambilias', '80145', '1245956312', 'something', 0x3138373230302d7469706f732d706f6b656d6f6e2d6d61706c65726f73652e6a7067, 1, ''),
(7, 'Israel', 'Hernandez', 'Perez', 'Flor de Liz', '6452', 'Bugambilias', '80145', '6672509472', 'something', 0x6d6f6e6473746164742e6a7067, 2, ''),
(8, 'Lucia de Dios', 'Villa', 'Aguilasocho', 'Flor de Liz', '6452', 'Bugambilias', '80145', '1245956312', 'ALGO', 0x3138373230302d7469706f732d706f6b656d6f6e2d6d61706c65726f73652e6a7067, 2, ''),
(9, 'Jose Alberto', 'Pablos', 'Berrelleza', 'Flor de Liz', '6452', 'Bugambilias', '80145', '1245956312', 'ALGO', 0x3138373230302d7469706f732d706f6b656d6f6e2d6d61706c65726f73652e6a7067, 2, 'Respuesta'),
(10, 'Andrea', 'Gil', 'Gamez', 'Flor de Liz', '6452', 'Azahares', '80145', '1245956312', 'something', 0x636865636b2d6d61726b2e706e67, 2, 'No tiene buena actitud.'),
(11, 'Pedro', 'Tanamachi', 'Garza', 'Flor de Liz', '6452', 'Azahares', '80145', '1245956312', 'something', 0x3138373230302d7469706f732d706f6b656d6f6e2d6d61706c65726f73652e6a7067, 3, 'Respuesta'),
(12, 'Patricia Aracely', 'Hdez', 'Lopez', 'Flor de Liz', '6452', 'Bugambilias', '80145', '6672509472', 'ALGO', 0x636865636b2d6d61726b2e706e67, 1, ''),
(13, 'Lucia de Dios', 'Villa', 'Lopez', 'Flor de Liz', '6452', 'Bugambilias', '80145', '6672509472', 'ALGO', 0x32396333336131306532316438343835303630623033633266366338663930642e6a7067, 1, ''),
(14, 'Jose Alberto', 'Pablos', 'Gamez', 'Flor de Liz', '6452', 'Bugambilias', '80145', '6672509472', 'something', 0x3138373230302d7469706f732d706f6b656d6f6e2d6d61706c65726f73652e6a7067, 2, 'Respuesta');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `estatus`
--
ALTER TABLE `estatus`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `prospectos`
--
ALTER TABLE `prospectos`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `estatus`
--
ALTER TABLE `estatus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `prospectos`
--
ALTER TABLE `prospectos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
