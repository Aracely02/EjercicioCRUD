<?php

    $inc = include("db_conn.php"); //conexión a base de datos

    if($inc){
        $query = "SELECT * FROM prospectos"; //se traen los registros de la base de datos

        $respuesta = mysqli_query($conn, $query); //se realiza la peticion
?>
                <table class="table table-hover" style="margin-top:30px;">
                <thead>
                    <tr>
                    <th scope="col">#</th>
                    <th scope="col">Nombre</th>
                    <th scope="col">Apellido paterno</th>
                    <th scope="col">Apellido materno</th>
                    <th scope="col">Estatus</th>
                    <th scope="col">Acciones</th>
                    </tr>
                </thead>
<?php
        if($respuesta){ //si mi peticion es valida (?)
            while($fila = $respuesta->fetch_array()){ //ciclo de iteracion para recorrer el arreglo
                //cacheo de datos
                $id = $fila['id'];
                $nombre = $fila['nombre'];
                $apellido_p = $fila['apellido_p'];
                $apellido_m = $fila['apellido_m'];
                $estatus = $fila['estatus'];
?>
                    <div>
                        <!-- se despliegan los datos con estructura de tabla -->
                        <tbody>
                            <tr>
                                <th scope="row"><?php echo $id;?></th>
                                <td><?php echo $nombre;?></td>
                                <td><?php echo $apellido_p;?></td>
                                <td><?php echo $apellido_m; ?></td>
                                <td><?php echo $estatus; ?></td>
                                <td> 
                                    <!-- Botón para ver detalle -->
                                    <button type="button" class="btn btn-success" id="btnDetalle<?php echo $id;?>" onclick='location.href="pantalla_listado_detalle.php?id=<?php echo $id;?>"';>Ver detalle</button>
                                    <button type="button" class="btn btn-danger" id="btnEvaluacion<?php echo $id;?>" onclick='location.href="pantalla_evaluacion.php?id=<?php echo $id;?>"';>Evaluar</button>
                                </td>
                            </tr>
                        </tbody>        
                    </div>
                
<?php
            }
        }
        echo("</table>");  
    }

?>